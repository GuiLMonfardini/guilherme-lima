# Aprendendo Pwa no Heroku

Site simples pra comecar o aprendizado da tecnologia PWA

## Como usar este repositorio

### Branch projetoinicialmaissimples
    Essa branch projetoinicialmasisimples mostra o projeto no inicio do aprendizado, ou seja, o projeto sendo um site simples do simples sem nada so um html puro.
    O projeto do jeito que esta nesse branch pode ser enviado para o heroku



### Branch projetocommanifest
    Neste branch o projeto tera um manifest mais simples possivel tornando o site um pwa mais simples possivel


## Como utilizar esse repositorio
### Clonando este repositorio

```sh
$ git clone https://github.com/wagnermarques/aprendendopwa.git
$ cd aprendendopwa
$ heroku create
$ git push heroku main
$ heroku open
```
